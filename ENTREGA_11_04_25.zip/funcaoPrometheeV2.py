import pandas as pd
import ortools
import numpy as np
from pymcdm.methods import PROMETHEE_II
from pymcdm.helpers import rrankdata
from ortools.linear_solver import pywraplp
#import PySimpleGUI as sg
import warnings
warnings.filterwarnings('ignore')
import tratamentoMOC
from geographiclib.geodesic import Geodesic
geod = Geodesic.WGS84

def CheckPlanilha(df, SisRecomen):
    '''
    Verifica se a planilha tem
    a primeira linha 'peso'
    a segunda linha 'tipo'
    a terceira linha 'q'
    a quarta linha 'p'
    a ultima coluna 'ranking'
    '''
    #print('check')
    TudoOk = False
    print(SisRecomen)

    # check if SisRecomen is false


    if SisRecomen == False:
        if (df.iloc[0,0] == 'peso' and
            df.iloc[1,0] == 'tipo' and
            df.iloc[2,0] == 'q' and
            df.iloc[3,0] == 'p' and
            df.columns[-1] == 'ranking'):
            TudoOk = True

        return TudoOk
    
    elif SisRecomen == True:
        if (df.iloc[0,0] == 'peso' and
            df.iloc[1,0] == 'tipo' and
            df.iloc[2,0] == 'q' and
            df.iloc[3,0] == 'p' and
            df.columns[-4] == 'lat' and
            df.columns[-3] == 'long' and
            df.columns[-2] == 'VENDOR' and
            df.columns[-1] == 'UF'):
            TudoOk = True
            print('Tudo ok', TudoOk)
    
    
    return TudoOk


def CalculaDistancia(lat1,long1,lat2,long2):
    '''
    Calcula a distancia em KM
    '''
    calculo =  geod.Inverse(lat1 ,long1, lat2,long2)
    distancia = calculo['s12']

    return round((distancia / 1000),2) # retorno em Km


def PrometheeRecomendacao(df):
    '''
    Executa o promethee e depois o sistema de recomendacao

    df - dados de entrada
    NumMaxRanking - Ranking principal cortado nesse valor
    NumRecomendacoes - Quantas OCs recomentar para cada OC do Ranking principal
    qRecomendacao - Indiferenca na distancia
    pRecomendacao - rampa de preferencia na distancia
    PrefixoArqSaida - Prefixo do Arquivo de saida
    NomeArquivoOriginal
    UsarRankingSeparado - Pra usar o ranking separado de OCs. Avaliar se vai manter isso aqui. 
    '''
    ## Teste

    ## Teste
    # print('PROMETHEE RECOMENDACAO')
    # # PRIORIZACAO
    # NumMaxRanking = 50              # Numero de OCs do Ranking principal
    # NumRecomendacoes = 2             # Recomendações por OC do Ranking Principal
    # PesoDistanciaRecomendacao = 0.50 # para o sistema de recomendação são dois fatores
    #                                 # o Ranking Global e a distancia a OC principal e esse é o
    #                                 # peso da distancia e o complemento é o peso do rankingGlobal
    # # SISTEMA DE RECOMENDACAO
    # qRecomendacao = 10 # km          # Fator de indiferenca do PROMETHEE para a distancia na recomendacao 
    # pRecomendacao = 30 # km          # Fator de rampa do PROMETHEE para a distancia na recomendacao
    # RECOMENDACOES = 0.2              # 20% de NumMaxRanking será recomendado

    # # PROGRAMACAO LINEAR               
    # RESTRICAO_VENDOR = 0.1           # RESTRICAO VENDOR. Pelo menos 10% das OC do Ranking principal
    #                                 # tem que ser alocadas para cada vendor 
    # RESTRICAO_UF = 0.03              # Pelo menos 3% das OCs do Ranking principal tem que ser 
    #                                 # de cada UF

    # # NomeArquivoOriginal = r'priorizar.xlsx'
    # NomeArquivoOriginal = r'PRIORIZAR_NA_VERA_NAOATIVOS.xlsx'
    # df = pd.read_excel(NomeArquivoOriginal)

    PesoRankingRecomendacao = 1-PesoDistanciaRecomendacao
    weights = np.array(df.iloc[0,1:-5].astype(float)) # SOMA 1
    types = np.array(df.iloc[1,1:-5].astype(float)) # 1 quanto maior melhor.
                        #-1, quanto menor, menor.                       
    q = np.array(df.iloc[2,1:-5].astype(float)) # q ushape PROMETHEE II
    p = np.array(df.iloc[3,1:-5].astype(float)) # p ushape PROMETHEE II
    valores = np.array(df.iloc[4:,1:-5].astype(float)) # tirando a coluna com as OCs         
    pref = PROMETHEE_II('vshape_2')
    pref = pref(valores, weights, types, q=q, p=p)
    ranking = rrankdata(pref)

    df_passo1 = df.iloc[4:,]
    df_passo1['ranking'] = ranking
    #df_passo1.to_excel(novoArquivo, index= False)
    
    ### Parte II Rodar o PROMETHEE II PARA RECOMENDAR SITES
    # passo 1. tirar colunas q nao interessam
    df_passo1 = df_passo1.filter(['OC','ranking','lat','long','VENDOR', 'UF'])
    df_passo1 = df_passo1.sort_values(by='ranking', ascending= True)

    ### AJUSTE DE REGRAS DE NEGOCIO
    MinUF = round(NumMaxRanking * RESTRICAO_UF)
    #MinUF
    # SitesSelecionados = []
    # for uf in df_passo1['UF'].unique():
    #     filtered_rows = df_passo1[df_passo1['UF'] == uf].head(MinUF)
    #    # SitesUF = SitesUF.concat(filtered_rows['Site'])        
    #     SitesSelecionados.extend(filtered_rows['Site'].tolist())

    MinVendor = round(NumMaxRanking * RESTRICAO_VENDOR)
    # MinVendor
    # for vendor in df_passo1['vendor'].unique():
    #     filtered_rows = df_passo1[df_passo1['vendor'] == vendor].head(MinVendor)
    #    # SitesUF = SitesUF.concat(filtered_rows['Site'])        
    #     SitesSelecionados.extend(filtered_rows['Site'].tolist())

    # SitesSelecionados.extend(df_passo1.iloc[0:NumMaxRanking,]['Site'].tolist())
    # SitesSelecionados = list(set(SitesSelecionados))
    # len(SitesSelecionados)
    #dfTEMP_copy= df_passo1.query('Site in @SitesSelecionados')
    dfTEMP_copy = df_passo1

    ## PASSO 3 OR TOOLS
    ##############

    min_items_per_category_A = MinUF
    min_items_per_category_B = MinVendor
    # Replace with your desired maximum number of selected rows
    LIMIT = NumMaxRanking

    solver = pywraplp.Solver.CreateSolver('SCIP')

    num_rows = len(dfTEMP_copy)
    # BIG_M = 1000  # Adjust this large constant value

    # Total selected rows counter
    total_selected = solver.IntVar(0, num_rows, 'total_selected')

    # Variables: x[i] is 1 if row i is selected, 0 otherwise
    x = [solver.IntVar(0, 1, f'x_{i}') for i in range(num_rows)]

    # Constraints for categories in column A: UF
    categories_A = dfTEMP_copy['UF'].unique()
    for category in categories_A:
        category_count = sum(x[i] for i, row in enumerate(dfTEMP_copy.itertuples()) if row.UF == category)
        solver.Add(category_count >= min_items_per_category_A)

    # Similar constraints for categories in column B: Vendor
    categories_B = dfTEMP_copy['VENDOR'].unique()
    for category in categories_B:
        category_count = sum(x[i] for i, row in enumerate(dfTEMP_copy.itertuples()) if row.VENDOR == category)
        solver.Add(category_count >= min_items_per_category_B)

    # Objective: Minimize sum of ranking for selected rows
    solver.Minimize(solver.Sum([ranking * x[i] for i, ranking in enumerate(dfTEMP_copy['ranking'])]))

    # Total selected rows constraint (change operator as needed)
    solver.Add(solver.Sum(x) == LIMIT)  # Change to <= for a maximum

    # Solve the problem
    status = solver.Solve()
    if status == pywraplp.Solver.OPTIMAL:
        print('Solution:')
        selected_rows = [i for i in range(num_rows) if x[i].solution_value() == 1]
        print(f'Selected rows: {selected_rows}')
        print(len(selected_rows))       
        # Filter DataFrame based on selected rows
        selected_df = dfTEMP_copy.iloc[selected_rows]
        #print(f'Selected rows details:\n{selected_df}')
    else:
        print('No feasible solution found.')


 #####   ####

    # passo 2. separar o ranking em 2.
    # OCs Principais foram as selecionadas
    # OCs Fora Ranking são as demais
    dfOCsPrincipais = dfTEMP_copy.iloc[selected_rows]

    selected_rows_set = set(selected_rows)
    all_indices = set(range(len(dfTEMP_copy)))
    not_selected_indices = all_indices.difference(selected_rows_set)
    dfOCsForaRanking = dfTEMP_copy.iloc[list(not_selected_indices)]

    #dfOCsPrincipais = df_passo1.iloc[0:NumMaxRanking,]
    #dfOCsForaRanking = df_passo1.iloc[NumMaxRanking:,]
    
    # Passo 2.5 Verificar se é pra utilizar um ranking separado. Se sim
    # ler o arquivo e atualizar o ranking

    # passo 3. PRINCIPAL
    # Iterar o dfOCsPrinciais, filtranto pelo Vendor e depois
    # calculando a distancia de cada um deles ao dfOCsForaRanking
    # e rodar o Promethee, Salvar os NumRecomendacoes em um df

    Colunas = ['OC',
            'rankingGlobal',
            'distancia',
            'rankingLocal',
            'OCPrincipal']

    dfRecomendacoes = pd.DataFrame( columns=Colunas)
    dfOCsForaRanking_copy = dfOCsForaRanking.copy(deep=True)
    #listaOCsPrincipais = dfOCsPrincipais.iloc[:,0]
    for index, row in dfOCsPrincipais.iterrows():
        try:
            latOCPrin = row['lat']
            longOCPrin = row['long']
            vendorOCPrin = row['VENDOR']
            OCPrincipal = row['OC']
            #print(latOCPrin, longOCPrin, vendorOCPrin, OCPrincipal)
            #print(OCPrincipal,latOCPrin, longOCPrin, vendorOCPrin)
            df_temp = pd.DataFrame()
            df_temp = dfOCsForaRanking_copy.loc[dfOCsForaRanking_copy['VENDOR']==vendorOCPrin]

            try:
                df_temp['distancia'] = df_temp.apply(lambda x: CalculaDistancia(
                                                                                latOCPrin,
                                                                                longOCPrin,
                                                                                x['lat'],
                                                                                x['long']
                                                                                ), axis=1)
            except:
                print(index, ': Erro nas coordenadas')

            df_temp = df_temp.filter(['OC','ranking','distancia'])
            print(df_temp.shape)
            weights = np.array([PesoRankingRecomendacao, PesoDistanciaRecomendacao])
            types = np.array([-1,-1]) # menor ranking e distancia, melhor                     
            q = np.array([0,qRecomendacao]) # q ushape PROMETHEE II. zero pro ranking e 10km pra disy
            p = np.array([0,pRecomendacao]) # p ushape PROMETHEE II. 50km pra dist. Vshape2
            valores = np.array(df_temp.iloc[:,1:].astype(float)) # tirando a coluna com as OCs         

            pref = PROMETHEE_II('vshape_2')
            pref = pref(valores, weights, types, q=q, p=p)
            ranking = rrankdata(pref)
            df_temp['rankingLocal'] = ranking
            df_temp = df_temp.sort_values(by='rankingLocal', ascending= True)

            df_temp = df_temp.iloc[0:NumRecomendacoes,]  #corte nas recomendacoes pedidas
            df_temp['OCPrincipal'] = OCPrincipal
            # remover as OCs recomendadas do pool
            OCsRecomendadas = list(df_temp['OC'])
            # Retiro as OCs recomendadas da lista, pra nao recomendar uma mesma OC mais de uma vez. Pode ser revisto
            dfOCsForaRanking_copy= dfOCsForaRanking_copy.query('OC not in @OCsRecomendadas')
            df_temp.rename(columns={'ranking':'rankingGlobal'}, inplace = True)
            #df_temp
            #dfRecomendacoes.append(df_temp, ignore_index=True)
            dfRecomendacoes = pd.concat([dfRecomendacoes, df_temp], ignore_index=True)
           # dfRecomendacoes.append(df_temp, ignore_index=True)
           # dfRecomendacoes
            #type(dfRecomendacoes)
            #type(df_temp)
        except:
            pass
        
    dfRecomendacoes.rename(columns={'OC':'OCRecomendada'}, inplace = True)

    dfRecomendacoes = dfRecomendacoes.sort_values(by='rankingGlobal', ascending= True)
    TotalRecomendacoes = int(NumMaxRanking * RECOMENDACOES)
    dfRecomendacoes = dfRecomendacoes.iloc[0:TotalRecomendacoes,]
    dfRecomendacoes.iloc[0:TotalRecomendacoes,]
    print('Feito !')

    return dfOCsPrincipais, dfRecomendacoes


## Teste
print('PROMETHEE RECOMENDACAO')
# PRIORIZACAO
NumMaxRanking = 10              # Numero de OCs do Ranking principal
NumRecomendacoes = 1             # Recomendações por OC do Ranking Principal
PesoDistanciaRecomendacao = 0.50 # para o sistema de recomendação são dois fatores
                                 # o Ranking Global e a distancia a OC principal e esse é o
                                 # peso da distancia e o complemento é o peso do rankingGlobal
# SISTEMA DE RECOMENDACAO
qRecomendacao = 10 # km          # Fator de indiferenca do PROMETHEE para a distancia na recomendacao 
pRecomendacao = 30 # km          # Fator de rampa do PROMETHEE para a distancia na recomendacao
RECOMENDACOES = 0.1              # 20% de NumMaxRanking será recomendado

# PROGRAMACAO LINEAR               
RESTRICAO_VENDOR = 0.1           # RESTRICAO VENDOR. Pelo menos 10% das OC do Ranking principal
                                 # tem que ser alocadas para cada vendor 
RESTRICAO_UF = 0.00              # Pelo menos 3% das OCs do Ranking principal tem que ser 
                                 # de cada UF

#NomeArquivoOriginal = r'priorizar1.xlsx'
NomeArquivoOriginal = r'PRIORIZAR2.xlsx'

#df = pd.read_excel(NomeArquivoOriginal)

df1 = tratamentoMOC.carregar_dados()
df1
dfPrin, dfRecom = PrometheeRecomendacao(df1)
dfPrin
dfRecom
dfPrin.to_excel('RankingPrincipal.xlsx', index=False)

dfRecom.to_excel('RankingRecomendacao.xlsx', index = False)